public = 1
'''
make sure public is set to 1, when I code for myself
the general functions folder is used for all of my separate
projects, but since that would confuse other people only
those functions relevant to this project are used.
'''