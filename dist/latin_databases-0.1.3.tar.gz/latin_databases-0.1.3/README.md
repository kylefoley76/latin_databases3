

This software merges several Latin databases into one.  These databases are 

1. COLLATINUS

found here:

https://github.com/biblissima/collatinus/tree/Daemon

And on the web here:

https://outils.biblissima.fr/en/collatinus-web/



2. LASLA or OPERA LATINA

found here:

http://cipl93.philo.ulg.ac.be/operalatina/



3. PEDECERTO

found here:

https://www.pedecerto.eu/public/

Only about 75% of this database is currently being used.



4. OXFORD LATIN DICTIONARY

Due to copyright restrictions only a list of words found in the Oxford Latin Dictionary is available.  We also use the vowel quantity and the known spelling variants of these words from the Oxford Latin Dictionary.  No definitions or examples of word usage is available. 


This project is not yet complete.  Roughly 90% of the words found in the LASLA database have been matched to the Collatinus database. 



